
import React, { useState } from 'react';
import type { StockItem } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface StockProps {
    stock: StockItem[];
    setStock: React.Dispatch<React.SetStateAction<StockItem[]>>;
}

const StockModal: React.FC<{
    item: StockItem | null;
    onClose: () => void;
    onSave: (item: StockItem) => void;
}> = ({ item, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<StockItem, 'id'>>({
        name: item?.name || '',
        category: item?.category || '',
        quantity: item?.quantity || 0,
        buyingPrice: item?.buyingPrice || 0,
        sellingPrice: item?.sellingPrice || 0,
        lowStockThreshold: item?.lowStockThreshold || 10,
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name.includes('Price') || name === 'quantity' || name === 'lowStockThreshold' ? Number(value) : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: item?.id || Date.now(), ...formData });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-lg shadow-xl text-gray-800 dark:text-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{item ? 'Edit Stock Item' : 'Add Stock Item'}</h2>
                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="col-span-2">
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Item Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" required />
                    </div>
                     <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category</label>
                        <input type="text" name="category" id="category" value={formData.category} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                     <div>
                        <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Quantity</label>
                        <input type="number" name="quantity" id="quantity" value={formData.quantity} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="buyingPrice" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Buying Price (UGX)</label>
                        <input type="number" name="buyingPrice" id="buyingPrice" value={formData.buyingPrice} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                     <div>
                        <label htmlFor="sellingPrice" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Selling Price (UGX)</label>
                        <input type="number" name="sellingPrice" id="sellingPrice" value={formData.sellingPrice} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div className="col-span-2">
                         <label htmlFor="lowStockThreshold" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Low Stock Threshold</label>
                        <input type="number" name="lowStockThreshold" id="lowStockThreshold" value={formData.lowStockThreshold} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div className="flex justify-end space-x-4 col-span-2 mt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Item</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const Stock: React.FC<StockProps> = ({ stock, setStock }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<StockItem | null>(null);

    const handleOpenModal = (item: StockItem | null = null) => {
        setEditingItem(item);
        setIsModalOpen(true);
    };

    const handleSaveItem = (item: StockItem) => {
        const index = stock.findIndex(s => s.id === item.id);
        if (index > -1) {
            setStock(stock.map(s => s.id === item.id ? item : s));
        } else {
            setStock([...stock, item]);
        }
    };

    const handleDeleteItem = (itemId: number) => {
        if (window.confirm('Are you sure you want to delete this stock item?')) {
            setStock(stock.filter(s => s.id !== itemId));
        }
    };

    return (
        <div>
            {isModalOpen && <StockModal item={editingItem} onClose={() => setIsModalOpen(false)} onSave={handleSaveItem} />}
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Stock</h1>
                <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Item
                </button>
            </div>
            <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                        <tr>
                            <th className="px-3 sm:px-6 py-3">Item</th>
                            <th className="px-3 sm:px-6 py-3">Category</th>
                            <th className="px-3 sm:px-6 py-3">Quantity</th>
                            <th className="px-3 sm:px-6 py-3">Buying Price</th>
                            <th className="px-3 sm:px-6 py-3">Selling Price</th>
                            <th className="px-3 sm:px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {stock.map(item => (
                            <tr key={item.id} className={`border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent ${item.quantity <= item.lowStockThreshold ? 'bg-yellow-50 dark:bg-yellow-900/20' : ''}`}>
                                <td className="px-3 sm:px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">{item.name}</td>
                                <td className="px-3 sm:px-6 py-4">{item.category}</td>
                                <td className="px-3 sm:px-6 py-4">{item.quantity}</td>
                                <td className="px-3 sm:px-6 py-4">UGX {item.buyingPrice.toLocaleString()}</td>
                                <td className="px-3 sm:px-6 py-4">UGX {item.sellingPrice.toLocaleString()}</td>
                                <td className="px-3 sm:px-6 py-4 text-right space-x-2">
                                    <button onClick={() => handleOpenModal(item)} className="p-2 text-blue-500 hover:text-blue-700"><EditIcon className="h-5 w-5" /></button>
                                    <button onClick={() => handleDeleteItem(item.id)} className="p-2 text-red-500 hover:text-red-700"><TrashIcon className="h-5 w-5" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {stock.length === 0 && <p className="text-center text-gray-500 py-6">No stock items found.</p>}
            </div>
        </div>
    );
};

export default Stock;