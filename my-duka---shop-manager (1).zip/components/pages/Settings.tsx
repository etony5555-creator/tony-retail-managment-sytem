import React, { useState } from 'react';

const Settings: React.FC = () => {
    const [settings, setSettings] = useState({
        shopName: 'My Duka',
        currency: 'UGX',
        contactPhone: '0700000000',
        contactEmail: 'myduka@shop.com'
    });
    const [isSaved, setIsSaved] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setSettings({ ...settings, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically save to a backend or local storage
        console.log('Settings saved:', settings);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000); // Hide message after 3 seconds
    };

    return (
        <div>
            <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light mb-6">Settings</h1>
            <div className="bg-white dark:bg-dark-card p-8 rounded-lg shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit}>
                    <div className="space-y-6">
                        <div>
                            <label htmlFor="shopName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Shop Name</label>
                            <input
                                type="text"
                                name="shopName"
                                id="shopName"
                                value={settings.shopName}
                                onChange={handleChange}
                                className="mt-1 block w-full px-3 py-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                            />
                        </div>

                        <div>
                            <label htmlFor="currency" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Currency</label>
                            <select
                                id="currency"
                                name="currency"
                                value={settings.currency}
                                onChange={handleChange}
                                className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-gray-50 dark:bg-dark-accent border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
                            >
                                <option>UGX</option>
                                <option>KES</option>
                                <option>TZS</option>
                                <option>USD</option>
                            </select>
                        </div>

                         <div>
                            <label htmlFor="contactPhone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Contact Phone</label>
                            <input
                                type="tel"
                                name="contactPhone"
                                id="contactPhone"
                                value={settings.contactPhone}
                                onChange={handleChange}
                                className="mt-1 block w-full px-3 py-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                            />
                        </div>

                         <div>
                            <label htmlFor="contactEmail" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Contact Email</label>
                            <input
                                type="email"
                                name="contactEmail"
                                id="contactEmail"
                                value={settings.contactEmail}
                                onChange={handleChange}
                                className="mt-1 block w-full px-3 py-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                            />
                        </div>
                    </div>

                    <div className="mt-8 flex justify-end items-center">
                        {isSaved && <span className="text-green-500 mr-4">Settings saved successfully!</span>}
                        <button
                            type="submit"
                            className="btn btn-primary"
                        >
                            Save Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Settings;