
import React, { useState } from 'react';
import type { Task } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface TasksProps {
    tasks: Task[];
    setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

const TaskModal: React.FC<{
    task: Task | null;
    onClose: () => void;
    onSave: (task: Task) => void;
}> = ({ task, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<Task, 'id' | 'status'>>({
        description: task?.description || '',
        dueDate: task?.dueDate || new Date().toISOString().split('T')[0]
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: task?.id || Date.now(), status: task?.status || 'Pending', ...formData });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{task ? 'Edit Task' : 'Add Task'}</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                        <input type="text" name="description" id="description" value={formData.description} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" required />
                    </div>
                    <div>
                        <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Due Date</label>
                        <input type="date" name="dueDate" id="dueDate" value={formData.dueDate} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" required />
                    </div>
                    <div className="flex justify-end space-x-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Task</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const Tasks: React.FC<TasksProps> = ({ tasks, setTasks }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingTask, setEditingTask] = useState<Task | null>(null);

    const handleSave = (task: Task) => {
        const index = tasks.findIndex(t => t.id === task.id);
        if (index > -1) {
            setTasks(tasks.map(t => t.id === task.id ? task : t));
        } else {
            setTasks([...tasks, task]);
        }
    };

    const handleDelete = (id: number) => {
        if (window.confirm('Are you sure you want to delete this task?')) {
            setTasks(tasks.filter(t => t.id !== id));
        }
    };

    const toggleStatus = (id: number) => {
        setTasks(tasks.map(t => t.id === id ? { ...t, status: t.status === 'Pending' ? 'Completed' : 'Pending' } : t));
    };

    const pendingTasks = tasks.filter(t => t.status === 'Pending').sort((a,b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    const completedTasks = tasks.filter(t => t.status === 'Completed').sort((a,b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());

    return (
        <div>
            {isModalOpen && <TaskModal task={editingTask} onClose={() => setIsModalOpen(false)} onSave={handleSave} />}
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Tasks</h1>
                <button onClick={() => { setEditingTask(null); setIsModalOpen(true); }} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Task
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h2 className="text-xl font-semibold mb-4 text-dark dark:text-light">Pending ({pendingTasks.length})</h2>
                    <div className="space-y-4">
                        {pendingTasks.map(task => (
                            <div key={task.id} className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div className="flex-grow">
                                    <p className="font-medium text-gray-800 dark:text-gray-200">{task.description}</p>
                                    <p className="text-sm text-red-500">Due: {task.dueDate}</p>
                                </div>
                                <div className="flex items-center space-x-2 flex-shrink-0 self-end sm:self-center">
                                     <button onClick={() => toggleStatus(task.id)} title="Mark as Completed" className="text-green-500 hover:text-green-700 p-1 font-bold text-xl">✓</button>
                                    <button onClick={() => { setEditingTask(task); setIsModalOpen(true); }} className="p-1 text-blue-500 hover:text-blue-700"><EditIcon className="h-4 w-4" /></button>
                                    <button onClick={() => handleDelete(task.id)} className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="h-4 w-4" /></button>
                                </div>
                            </div>
                        ))}
                         {pendingTasks.length === 0 && <p className="text-center text-gray-500 py-6">No pending tasks.</p>}
                    </div>
                </div>
                 <div>
                    <h2 className="text-xl font-semibold mb-4 text-dark dark:text-light">Completed ({completedTasks.length})</h2>
                     <div className="space-y-4">
                        {completedTasks.map(task => (
                            <div key={task.id} className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 opacity-60">
                                <div className='flex-grow'>
                                    <p className="font-medium text-gray-800 dark:text-gray-200 line-through">{task.description}</p>
                                    <p className="text-sm text-gray-500">Completed on: {task.dueDate}</p>
                                </div>
                                 <div className="flex items-center space-x-2 flex-shrink-0 self-end sm:self-center">
                                    <button onClick={() => toggleStatus(task.id)} title="Mark as Pending" className="text-yellow-500 hover:text-yellow-700 p-1 font-bold text-xl">⮌</button>
                                    <button onClick={() => handleDelete(task.id)} className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="h-4 w-4" /></button>
                                </div>
                            </div>
                        ))}
                         {completedTasks.length === 0 && <p className="text-center text-gray-500 py-6">No completed tasks yet.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Tasks;