import React, { useState, useMemo, useEffect } from 'react';
import type { Borrower, BorrowingRecord, Customer } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface BorrowingProps {
    borrowers: Borrower[];
    setBorrowers: React.Dispatch<React.SetStateAction<Borrower[]>>;
    records: BorrowingRecord[];
    setRecords: React.Dispatch<React.SetStateAction<BorrowingRecord[]>>;
    customers: Customer[];
}

const BorrowerModal: React.FC<{
    borrower: Borrower | null;
    customers: Customer[];
    borrowers: Borrower[];
    onClose: () => void;
    onSave: (borrower: Borrower) => void;
}> = ({ borrower, customers, borrowers, onClose, onSave }) => {
    const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');

    const unlinkedCustomers = useMemo(() => {
        const borrowerIds = new Set(borrowers.map(b => b.id));
        return customers.filter(c => !borrowerIds.has(c.id));
    }, [customers, borrowers]);

    useEffect(() => {
        if (borrower) {
            setName(borrower.name);
            setPhone(borrower.phone);
        } else {
            setName('');
            setPhone('');
            setSelectedCustomerId('');
        }
    }, [borrower]);

    useEffect(() => {
        if (selectedCustomerId) {
            const customer = customers.find(c => c.id === Number(selectedCustomerId));
            if (customer) {
                setName(customer.name);
                setPhone(customer.phone);
            }
        } else if (!borrower) {
            setName('');
            setPhone('');
        }
    }, [selectedCustomerId, customers, borrower]);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: borrower?.id || Number(selectedCustomerId) || Date.now(), name, phone });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl text-gray-800 dark:text-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{borrower ? 'Edit Borrower' : 'Add Borrower'}</h2>
                <form onSubmit={handleSubmit}>
                    {!borrower && (
                        <div className="mb-4">
                            <label htmlFor="customer-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select from Customers (Optional)</label>
                            <select id="customer-select" value={selectedCustomerId} onChange={e => setSelectedCustomerId(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md">
                                <option value="">-- Add New Borrower --</option>
                                {unlinkedCustomers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                    )}
                    <div className="mb-4">
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Name</label>
                        <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} disabled={!!selectedCustomerId} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md disabled:bg-gray-200 dark:disabled:bg-gray-700" />
                    </div>
                     <div className="mb-6">
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Phone</label>
                        <input type="tel" id="phone" value={phone} onChange={e => setPhone(e.target.value)} disabled={!!selectedCustomerId} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md disabled:bg-gray-200 dark:disabled:bg-gray-700" />
                    </div>
                    <div className="flex justify-end space-x-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Borrower</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const BorrowingRecordModal: React.FC<{
    record: Partial<BorrowingRecord> | null;
    borrowers: Borrower[];
    onClose: () => void;
    onSave: (record: BorrowingRecord) => void;
}> = ({ record, borrowers, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<BorrowingRecord, 'id'>>({
        borrowerId: 0, amount: 0, date: '', dueDate: '', status: 'Unpaid', isRecurring: false, frequency: 'Monthly', endDate: '', occurrences: 1
    });
    const [endCondition, setEndCondition] = useState<'date' | 'occurrences'>('date');

    useEffect(() => {
        setFormData({
            borrowerId: record?.borrowerId || (borrowers[0]?.id || 0),
            amount: record?.amount || 0,
            date: record?.date || new Date().toISOString().split('T')[0],
            dueDate: record?.dueDate || '',
            status: record?.status || 'Unpaid',
            isRecurring: record?.isRecurring || false,
            frequency: record?.frequency || 'Monthly',
            endDate: record?.endDate || '',
            occurrences: record?.occurrences || 1
        });
    }, [record, borrowers]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ ...formData, id: record?.id || Date.now(), borrowerId: Number(formData.borrowerId) });
        onClose();
    };
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
             setFormData(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
        } else {
             setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 overflow-y-auto py-4">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl text-gray-800 dark:text-gray-200 my-auto">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{record && 'id' in record ? 'Edit' : 'Add'} Borrowing Record</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="borrowerId" className="block text-sm font-medium mb-1">Borrower</label>
                        <select name="borrowerId" value={formData.borrowerId} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md">
                            {borrowers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="amount" className="block text-sm font-medium mb-1">Amount (UGX)</label>
                        <input type="number" name="amount" value={formData.amount} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="date" className="block text-sm font-medium mb-1">Date</label>
                        <input type="date" name="date" value={formData.date} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="dueDate" className="block text-sm font-medium mb-1">Due Date</label>
                        <input type="date" name="dueDate" value={formData.dueDate} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                     <div className="pt-2">
                        <label className="flex items-center space-x-2">
                            <input type="checkbox" name="isRecurring" checked={formData.isRecurring} onChange={handleChange} className="h-4 w-4 rounded text-primary focus:ring-primary"/>
                            <span className="text-sm font-medium">Set as Recurring</span>
                        </label>
                    </div>
                    {formData.isRecurring && (
                        <div className="p-4 border rounded-md bg-gray-50 dark:bg-dark-accent dark:border-gray-600 space-y-4">
                             <div>
                                <label htmlFor="frequency" className="block text-sm font-medium mb-1">Frequency</label>
                                <select name="frequency" value={formData.frequency} onChange={handleChange} className="w-full p-2 bg-white dark:bg-dark border border-gray-300 dark:border-gray-500 rounded-md">
                                    <option>Daily</option>
                                    <option>Weekly</option>
                                    <option>Monthly</option>
                                </select>
                            </div>
                            <div className="space-y-2">
                                <label className="block text-sm font-medium">End Condition</label>
                                <div className="flex items-center space-x-4">
                                    <label className="flex items-center space-x-2"><input type="radio" name="endCondition" checked={endCondition === 'date'} onChange={() => setEndCondition('date')} /> <span>On Date</span></label>
                                    <label className="flex items-center space-x-2"><input type="radio" name="endCondition" checked={endCondition === 'occurrences'} onChange={() => setEndCondition('occurrences')} /> <span>After</span></label>
                                </div>
                                {endCondition === 'date' ? (
                                    <input type="date" name="endDate" value={formData.endDate} onChange={handleChange} className="w-full p-2 bg-white dark:bg-dark border border-gray-300 dark:border-gray-500 rounded-md" />
                                ):(
                                    <div className="flex items-center space-x-2">
                                        <input type="number" name="occurrences" value={formData.occurrences} onChange={handleChange} className="w-20 p-2 bg-white dark:bg-dark border border-gray-300 dark:border-gray-500 rounded-md" />
                                        <span>occurrences</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                    <div className="flex justify-end space-x-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const Borrowing: React.FC<BorrowingProps> = ({ borrowers, setBorrowers, records, setRecords, customers }) => {
    const [selectedBorrower, setSelectedBorrower] = useState<Borrower | null>(borrowers[0] || null);
    
    const [isBorrowerModalOpen, setIsBorrowerModalOpen] = useState(false);
    const [editingBorrower, setEditingBorrower] = useState<Borrower | null>(null);
    
    const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
    const [editingRecord, setEditingRecord] = useState<BorrowingRecord | null>(null);

    const outstandingBalances = useMemo(() => {
        const balances = new Map<number, number>();
        borrowers.forEach(b => {
            const outstanding = records
                .filter(r => r.borrowerId === b.id && r.status === 'Unpaid')
                .reduce((sum, r) => sum + r.amount, 0);
            balances.set(b.id, outstanding);
        });
        return balances;
    }, [records, borrowers]);

    const handleSaveBorrower = (borrower: Borrower) => {
        const index = borrowers.findIndex(b => b.id === borrower.id);
        if (index > -1) {
            setBorrowers(borrowers.map(b => b.id === borrower.id ? borrower : b));
        } else {
            setBorrowers([...borrowers, borrower]);
        }
    };
    
    const handleDeleteBorrower = (borrowerId: number) => {
        if(window.confirm('Are you sure? Deleting a borrower will also delete all their records.')) {
            setBorrowers(borrowers.filter(b => b.id !== borrowerId));
            setRecords(records.filter(r => r.borrowerId !== borrowerId));
            if(selectedBorrower?.id === borrowerId) {
                setSelectedBorrower(borrowers.length > 1 ? borrowers.filter(b => b.id !== borrowerId)[0] : null);
            }
        }
    };
    
    const handleSaveRecord = (record: BorrowingRecord) => {
        const index = records.findIndex(r => r.id === record.id);
        if (index > -1) {
            setRecords(records.map(r => r.id === record.id ? record : r));
        } else {
            setRecords([...records, record]);
        }
    };
    
    const handleDeleteRecord = (recordId: number) => {
        setRecords(records.filter(r => r.id !== recordId));
    };

    const toggleRecordStatus = (recordId: number) => {
        setRecords(records.map(r => r.id === recordId ? {...r, status: r.status === 'Paid' ? 'Unpaid' : 'Paid' } : r));
    };

    const borrowerRecords = selectedBorrower ? records.filter(r => r.borrowerId === selectedBorrower.id) : [];

    return (
        <div>
            {isBorrowerModalOpen && <BorrowerModal borrower={editingBorrower} customers={customers} borrowers={borrowers} onClose={() => setIsBorrowerModalOpen(false)} onSave={handleSaveBorrower} />}
            {isRecordModalOpen && <BorrowingRecordModal record={editingRecord} borrowers={borrowers} onClose={() => setIsRecordModalOpen(false)} onSave={handleSaveRecord} />}

            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Borrowing</h1>
                 <button onClick={() => { setEditingRecord(null); setIsRecordModalOpen(true); }} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Record
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 bg-white dark:bg-dark-card p-6 rounded-lg shadow-md">
                    <div className="flex flex-col gap-2 sm:flex-row sm:justify-between sm:items-center mb-4">
                        <h2 className="text-xl font-semibold text-dark dark:text-light">Borrowers</h2>
                        <button onClick={() => { setEditingBorrower(null); setIsBorrowerModalOpen(true); }} className="px-3 py-1 bg-gray-200 text-gray-700 dark:bg-dark-accent dark:text-gray-200 text-sm rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 self-start sm:self-auto">+ Add</button>
                    </div>
                    <ul className="space-y-2 max-h-[60vh] overflow-y-auto">
                        {borrowers.map(borrower => (
                            <li key={borrower.id} onClick={() => setSelectedBorrower(borrower)} className={`p-3 rounded-md cursor-pointer transition-colors group ${selectedBorrower?.id === borrower.id ? 'bg-blue-100 dark:bg-blue-900/50' : 'hover:bg-gray-100 dark:hover:bg-dark-accent'}`}>
                                <div className="flex justify-between items-center">
                                    <div>
                                        <p className="font-medium text-gray-800 dark:text-gray-100">{borrower.name}</p>
                                        <p className="text-sm text-red-500">Outstanding: UGX {(outstandingBalances.get(borrower.id) || 0).toLocaleString()}</p>
                                    </div>
                                    <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={(e) => { e.stopPropagation(); setEditingBorrower(borrower); setIsBorrowerModalOpen(true); }} className="p-1 text-blue-500 hover:text-blue-700"><EditIcon className="h-4 w-4"/></button>
                                        <button onClick={(e) => { e.stopPropagation(); handleDeleteBorrower(borrower.id); }} className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="h-4 w-4"/></button>
                                    </div>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="lg:col-span-2 bg-white dark:bg-dark-card p-6 rounded-lg shadow-md">
                    <h2 className="text-xl font-semibold mb-4 text-dark dark:text-light">
                        {selectedBorrower ? `${selectedBorrower.name}'s Records` : 'Select a Borrower'}
                    </h2>
                    {selectedBorrower ? (
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                                    <tr>
                                        <th className="px-2 sm:px-4 py-3">Date</th>
                                        <th className="px-2 sm:px-4 py-3">Amount</th>
                                        <th className="px-2 sm:px-4 py-3">Status</th>
                                        <th className="px-2 sm:px-4 py-3"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {borrowerRecords.map(record => (
                                        <tr key={record.id} className="bg-white dark:bg-dark-card border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                            <td className="px-2 sm:px-4 py-4">{record.date}</td>
                                            <td className="px-2 sm:px-4 py-4">UGX {record.amount.toLocaleString()}</td>
                                            <td className="px-2 sm:px-4 py-4">
                                                <button onClick={() => toggleRecordStatus(record.id)} className={`px-2 py-1 rounded-full text-xs font-medium ${record.status === 'Paid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                    {record.status}
                                                </button>
                                            </td>
                                            <td className="px-2 sm:px-4 py-4 text-right space-x-1">
                                                 <button onClick={() => { setEditingRecord(record); setIsRecordModalOpen(true); }} className="p-1 text-blue-500 hover:text-blue-700"><EditIcon className="h-4 w-4"/></button>
                                                <button onClick={() => handleDeleteRecord(record.id)} className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="h-4 w-4"/></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                             {borrowerRecords.length === 0 && <p className="text-center text-gray-500 py-8">No records for this borrower.</p>}
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                            <p>No borrower selected.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Borrowing;