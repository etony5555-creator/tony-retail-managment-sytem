import React from 'react';
import type { Page } from '../types';
import {
  DashboardIcon, CustomersIcon, StockIcon, FinanceIcon, BorrowingIcon,
  WholesalersIcon, BodaDriversIcon, TasksIcon, SettingsIcon, CloseIcon,
  SunIcon, MoonIcon
} from './icons/Icons';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
}

const navItems: { name: Page; icon: React.FC<{ className?: string }> }[] = [
  { name: 'Dashboard', icon: DashboardIcon },
  { name: 'Customers', icon: CustomersIcon },
  { name: 'Stock', icon: StockIcon },
  { name: 'Finance', icon: FinanceIcon },
  { name: 'Borrowing', icon: BorrowingIcon },
  { name: 'Wholesalers', icon: WholesalersIcon },
  { name: 'Boda Drivers', icon: BodaDriversIcon },
  { name: 'Tasks', icon: TasksIcon },
  { name: 'Settings', icon: SettingsIcon },
];

const ThemeToggle: React.FC<{ theme: 'light' | 'dark'; setTheme: (theme: 'light' | 'dark') => void; }> = ({ theme, setTheme }) => {
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <button onClick={toggleTheme} className="w-full flex items-center justify-center p-2 rounded-lg bg-dark-accent hover:bg-gray-700 transition-colors">
      {theme === 'light' ? (
        <><SunIcon className="h-5 w-5 text-yellow-400 mr-2" /> <span className="text-sm">Light Mode</span></>
      ) : (
        <><MoonIcon className="h-5 w-5 text-blue-400 mr-2" /> <span className="text-sm">Dark Mode</span></>
      )}
    </button>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, isOpen, setIsOpen, theme, setTheme }) => {
    const handleNavigation = (page: Page) => {
        setActivePage(page);
        if (window.innerWidth < 1024) { // Close sidebar on mobile after navigation
            setIsOpen(false);
        }
    };

  return (
    <>
      <div className={`fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsOpen(false)}></div>
      <aside className={`bg-dark text-white w-64 flex-shrink-0 flex flex-col fixed lg:relative inset-y-0 left-0 z-40 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out`}>
        <div className="flex items-center justify-between p-4 border-b border-dark-accent">
          <h1 className="text-2xl font-bold">My Duka</h1>
          <button onClick={() => setIsOpen(false)} className="lg:hidden text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </div>
        <nav className="flex-1 px-2 py-4 space-y-2">
          {navItems.map((item) => (
            <a
              key={item.name}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                handleNavigation(item.name);
              }}
              className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200 ${
                activePage === item.name
                  ? 'bg-primary text-white'
                  : 'text-gray-300 hover:bg-dark-accent hover:text-white'
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.name}
            </a>
          ))}
        </nav>
        <div className="p-4 border-t border-dark-accent space-y-4">
            <ThemeToggle theme={theme} setTheme={setTheme} />
            <p className="text-sm text-center text-gray-400">Shop Manager v1.0</p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;