import React from 'react';
import MetricCard from '../MetricCard';
import type { StockItem, Task } from '../../types';

interface DashboardMetrics {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    totalStockValue: number;
    outstandingDebt: number;
    creditToCustomers: number;
    lowStockItems: StockItem[];
    pendingTasks: Task[];
}

interface DashboardProps {
    metrics: DashboardMetrics;
}

const formatCurrency = (amount: number) => {
    return `UGX ${new Intl.NumberFormat('en-US').format(amount)}`;
};

const Dashboard: React.FC<DashboardProps> = ({ metrics }) => {
  const { 
    totalRevenue, totalExpenses, netProfit, totalStockValue, 
    outstandingDebt, creditToCustomers, lowStockItems, pendingTasks 
  } = metrics;
  
  const hasLowStock = lowStockItems.length > 0;

  return (
    <div>
      <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light mb-6">Dashboard</h1>
      
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <MetricCard title="Total Revenue" value={formatCurrency(totalRevenue)} />
        <MetricCard title="Total Expenses" value={formatCurrency(totalExpenses)} />
        <MetricCard title="Net Profit" value={formatCurrency(netProfit)} isNegative={netProfit < 0} />
        <MetricCard title="Total Stock Value" value={formatCurrency(totalStockValue)} />
        <MetricCard title="Outstanding Debt" value={formatCurrency(outstandingDebt)} isNegative={true}/>
        <MetricCard title="Credit to Customers" value={formatCurrency(creditToCustomers)} isNegative={creditToCustomers > 0} />
      </div>

      {/* Summaries Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low Stock Items */}
        <div className={`bg-white dark:bg-dark-card p-6 rounded-lg shadow-md transition-all ${hasLowStock ? 'animate-pulse-warning' : ''}`}>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-dark dark:text-light">Low Stock Items ({lowStockItems.length})</h2>
            <button className="text-sm text-primary hover:underline">View Stock</button>
          </div>
          {lowStockItems.length > 0 ? (
            <ul>
                {lowStockItems.map((item) => (
                <li key={item.id} className="flex justify-between items-center py-2 border-b last:border-b-0 border-gray-200 dark:border-gray-700">
                    <span className="text-gray-700 dark:text-gray-300">{item.name}</span>
                    <span className="font-medium text-yellow-600 bg-yellow-100 px-2 py-1 rounded-full text-xs">{item.quantity} left</span>
                </li>
                ))}
            </ul>
          ) : (
            <p className="text-gray-500 dark:text-gray-400 mt-4">All stock levels are good!</p>
          )}
        </div>

        {/* Pending Tasks */}
        <div className="bg-white dark:bg-dark-card p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-dark dark:text-light">Pending Tasks ({pendingTasks.length})</h2>
            <button className="text-sm text-primary hover:underline">View Tasks</button>
          </div>
          {pendingTasks.length > 0 ? (
            <ul>
                {pendingTasks.map((task) => (
                <li key={task.id} className="flex justify-between items-center py-2 border-b last:border-b-0 border-gray-200 dark:border-gray-700">
                    <span className="text-gray-700 dark:text-gray-300">{task.description}</span>
                    <span className="text-sm text-red-600">Due: {task.dueDate}</span>
                </li>
                ))}
            </ul>
           ) : (
             <p className="text-gray-500 dark:text-gray-400 mt-4">No pending tasks. Great job!</p>
           )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;