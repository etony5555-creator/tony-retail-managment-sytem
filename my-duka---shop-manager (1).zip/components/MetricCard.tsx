import React from 'react';

interface MetricCardProps {
  title: string;
  value: string;
  isNegative?: boolean;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, isNegative = false }) => {
  const valueColor = isNegative ? 'text-red-500' : 'text-gray-900 dark:text-gray-100';

  return (
    <div className="bg-white dark:bg-dark-card p-6 rounded-lg shadow-md hover:shadow-lg dark:hover:shadow-blue-500/20 transition-shadow duration-300">
      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
      <p className={`text-3xl font-bold mt-2 ${valueColor}`}>{value}</p>
    </div>
  );
};

export default MetricCard;