
import React, { useState, useEffect, useMemo } from 'react';
import type { Page, Customer, StockItem, FinanceRecord, Borrower, BorrowingRecord, Wholesaler, BodaDriver, Task } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/pages/Dashboard';
import Customers from './components/pages/Customers';
import Stock from './components/pages/Stock';
import Finance from './components/pages/Finance';
import Borrowing from './components/pages/Borrowing';
import Wholesalers from './components/pages/Wholesalers';
import BodaDrivers from './components/pages/BodaDrivers';
import Tasks from './components/pages/Tasks';
import Settings from './components/pages/Settings';
import { MenuIcon } from './components/icons/Icons';

// Initial Data moved here to be managed by the root component
const initialCustomers: Customer[] = [{ id: 1, name: 'Alice Johnson', phone: '0777123456' }, { id: 2, name: 'Bob Williams', phone: '0755987654' }];
const initialStock: StockItem[] = [{ id: 1, name: 'Cooking Oil', category: 'Groceries', quantity: 5, buyingPrice: 8000, sellingPrice: 10000, lowStockThreshold: 10 }, { id: 2, name: 'Sugar', category: 'Groceries', quantity: 20, buyingPrice: 4000, sellingPrice: 5000, lowStockThreshold: 15 }, { id: 3, name: 'Soda', category: 'Beverages', quantity: 50, buyingPrice: 1500, sellingPrice: 2000, lowStockThreshold: 24 }];
const initialFinanceRecords: FinanceRecord[] = [{ id: 1, type: 'Income', date: '2023-10-25', category: 'Sales', description: 'Daily sales', amount: 350000 }, { id: 2, type: 'Expense', date: '2023-10-24', category: 'Stock', description: 'Restock sugar and oil', amount: 150000 }, { id: 3, type: 'Expense', date: '2023-10-23', category: 'Utilities', description: 'Electricity bill', amount: 80000 }];
const initialBorrowers: Borrower[] = [{ id: 1, name: 'John Doe', phone: '0712345678' }, { id: 2, name: 'Jane Smith', phone: '0787654321' }];
const initialBorrowingRecords: BorrowingRecord[] = [{ id: 1, borrowerId: 1, amount: 30000, date: '2023-10-01', dueDate: '2023-11-01', status: 'Paid' }, { id: 2, borrowerId: 1, amount: 20000, date: '2023-10-15', dueDate: '2023-11-15', status: 'Unpaid' }, { id: 3, borrowerId: 2, amount: 120000, date: '2023-09-20', dueDate: '2023-10-20', status: 'Unpaid' }];
const initialWholesalers: Wholesaler[] = [{ id: 1, name: 'Kiboko Enterprises', contactPerson: 'Mr. Sharma', phone: '03122 Kiboko', productCategory: 'General Goods' }, { id: 2, name: 'Mukwano Group', contactPerson: 'Ms. Allen', phone: '0414304000', productCategory: 'Cooking Oil, Soap' }];
const initialDrivers: BodaDriver[] = [{ id: 1, name: 'Sula Kato', phone: '0701112233', stage: 'Kyanja', riderId: 'BK-101' }, { id: 2, name: 'Peter Musoke', phone: '0702445566', stage: 'Ntinda', riderId: 'BK-102' }];
const initialTasks: Task[] = [{ id: 1, description: 'Restock sugar', dueDate: '2023-10-28', status: 'Pending' }, { id: 2, description: 'Pay electricity bill', dueDate: '2023-10-30', status: 'Pending' }, { id: 3, description: 'Clean the shelves', dueDate: '2023-10-25', status: 'Completed' }];

const DateTimeDisplay: React.FC = () => {
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDateTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="text-sm text-center md:text-right text-gray-600 dark:text-gray-400">
      <div>{dateTime.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      <div>{dateTime.toLocaleTimeString()}</div>
    </div>
  );
};


const App: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>('Dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  
  // Centralized State Management
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [stock, setStock] = useState<StockItem[]>(initialStock);
  const [financeRecords, setFinanceRecords] = useState<FinanceRecord[]>(initialFinanceRecords);
  const [borrowers, setBorrowers] = useState<Borrower[]>(initialBorrowers);
  const [borrowingRecords, setBorrowingRecords] = useState<BorrowingRecord[]>(initialBorrowingRecords);
  const [wholesalers, setWholesalers] = useState<Wholesaler[]>(initialWholesalers);
  const [bodaDrivers, setBodaDrivers] = useState<BodaDriver[]>(initialDrivers);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Derived state for dashboard metrics
  const dashboardMetrics = useMemo(() => {
    const totalRevenue = financeRecords.filter(r => r.type === 'Income').reduce((sum, r) => sum + r.amount, 0);
    const totalExpenses = financeRecords.filter(r => r.type === 'Expense').reduce((sum, r) => sum + r.amount, 0);
    const totalStockValue = stock.reduce((sum, item) => sum + (item.buyingPrice * item.quantity), 0);
    const creditToCustomers = borrowingRecords.filter(r => r.status === 'Unpaid').reduce((sum, r) => sum + r.amount, 0);
    const lowStockItems = stock.filter(item => item.quantity <= item.lowStockThreshold);
    const pendingTasks = tasks.filter(task => task.status === 'Pending');

    return {
      totalRevenue,
      totalExpenses,
      netProfit: totalRevenue - totalExpenses,
      totalStockValue,
      outstandingDebt: 750000, // Placeholder
      creditToCustomers,
      lowStockItems,
      pendingTasks
    };
  }, [financeRecords, stock, borrowingRecords, tasks]);

  const renderPage = () => {
    switch (activePage) {
      case 'Dashboard':
        return <Dashboard metrics={dashboardMetrics} />;
      case 'Customers':
        return <Customers customers={customers} setCustomers={setCustomers} />;
      case 'Stock':
        return <Stock stock={stock} setStock={setStock} />;
      case 'Finance':
        return <Finance records={financeRecords} setRecords={setFinanceRecords} />;
      case 'Borrowing':
        return <Borrowing borrowers={borrowers} setBorrowers={setBorrowers} records={borrowingRecords} setRecords={setBorrowingRecords} customers={customers} />;
      case 'Wholesalers':
        return <Wholesalers wholesalers={wholesalers} setWholesalers={setWholesalers} />;
      case 'Boda Drivers':
        return <BodaDrivers drivers={bodaDrivers} setDrivers={setBodaDrivers} />;
      case 'Tasks':
        return <Tasks tasks={tasks} setTasks={setTasks} />;
      case 'Settings':
        return <Settings />;
      default:
        return <Dashboard metrics={dashboardMetrics} />;
    }
  };

  return (
    <div className="flex h-screen bg-light text-gray-800 dark:bg-dark dark:text-gray-200">
      <Sidebar activePage={activePage} setActivePage={setActivePage} isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} theme={theme} setTheme={setTheme} />
      <main className="flex-1 flex flex-col overflow-y-auto">
        <header className="bg-white dark:bg-dark-accent shadow-sm p-4 flex items-center justify-between lg:hidden sticky top-0 z-20">
            <button onClick={() => setIsSidebarOpen(true)} className="text-dark dark:text-light">
                <MenuIcon className="h-6 w-6" />
            </button>
            <h1 className="text-xl font-bold text-dark dark:text-light ml-4">{activePage}</h1>
        </header>
         <div className="hidden lg:flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-dark-accent">
            <h1 className="text-2xl font-bold text-dark dark:text-light">{activePage}</h1>
            <DateTimeDisplay />
        </div>
        <div className="p-4 md:p-8 flex-1">
          {renderPage()}
        </div>
      </main>
    </div>
  );
};

export default App;
