
import React, { useState } from 'react';
import type { BodaDriver } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface BodaDriversProps {
    drivers: BodaDriver[];
    setDrivers: React.Dispatch<React.SetStateAction<BodaDriver[]>>;
}

const DriverModal: React.FC<{
    driver: BodaDriver | null;
    onClose: () => void;
    onSave: (driver: BodaDriver) => void;
}> = ({ driver, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<BodaDriver, 'id'>>({
        name: driver?.name || '',
        phone: driver?.phone || '',
        stage: driver?.stage || '',
        riderId: driver?.riderId || ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: driver?.id || Date.now(), ...formData });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{driver ? 'Edit Driver' : 'Add Driver'}</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" required />
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="stage" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Stage</label>
                        <input type="text" name="stage" id="stage" value={formData.stage} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="riderId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Rider ID</label>
                        <input type="text" name="riderId" id="riderId" value={formData.riderId} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div className="flex justify-end space-x-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Driver</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const BodaDrivers: React.FC<BodaDriversProps> = ({ drivers, setDrivers }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingDriver, setEditingDriver] = useState<BodaDriver | null>(null);

    const handleSave = (driver: BodaDriver) => {
        const index = drivers.findIndex(d => d.id === driver.id);
        if (index > -1) {
            setDrivers(drivers.map(d => d.id === driver.id ? driver : d));
        } else {
            setDrivers([...drivers, driver]);
        }
    };

    const handleDelete = (id: number) => {
        if (window.confirm('Are you sure you want to delete this driver?')) {
            setDrivers(drivers.filter(d => d.id !== id));
        }
    };

    return (
        <div>
            {isModalOpen && <DriverModal driver={editingDriver} onClose={() => setIsModalOpen(false)} onSave={handleSave} />}
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Boda Drivers</h1>
                <button onClick={() => { setEditingDriver(null); setIsModalOpen(true); }} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Driver
                </button>
            </div>
            <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                        <tr>
                            <th className="px-3 sm:px-6 py-3">Name</th>
                            <th className="px-3 sm:px-6 py-3">Phone</th>
                            <th className="px-3 sm:px-6 py-3">Stage</th>
                            <th className="px-3 sm:px-6 py-3">Rider ID</th>
                            <th className="px-3 sm:px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {drivers.map(driver => (
                            <tr key={driver.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                <td className="px-3 sm:px-6 py-4 font-medium">{driver.name}</td>
                                <td className="px-3 sm:px-6 py-4">{driver.phone}</td>
                                <td className="px-3 sm:px-6 py-4">{driver.stage}</td>
                                <td className="px-3 sm:px-6 py-4">{driver.riderId}</td>
                                <td className="px-3 sm:px-6 py-4 text-right space-x-2">
                                    <button onClick={() => { setEditingDriver(driver); setIsModalOpen(true); }} className="p-2 text-blue-500 hover:text-blue-700"><EditIcon className="h-5 w-5" /></button>
                                    <button onClick={() => handleDelete(driver.id)} className="p-2 text-red-500 hover:text-red-700"><TrashIcon className="h-5 w-5" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {drivers.length === 0 && <p className="text-center text-gray-500 py-6">No drivers found.</p>}
            </div>
        </div>
    );
};

export default BodaDrivers;