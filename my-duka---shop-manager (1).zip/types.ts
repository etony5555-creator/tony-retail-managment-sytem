export type Page =
  | 'Dashboard'
  | 'Customers'
  | 'Stock'
  | 'Finance'
  | 'Borrowing'
  | 'Wholesalers'
  | 'Boda Drivers'
  | 'Tasks'
  | 'Settings';

export interface Borrower {
  id: number;
  name: string;
  phone: string;
}

export interface BorrowingRecord {
  id: number;
  borrowerId: number;
  amount: number;
  date: string;
  dueDate: string;
  status: 'Paid' | 'Unpaid';
  isRecurring?: boolean;
  frequency?: 'Daily' | 'Weekly' | 'Monthly';
  endDate?: string;
  occurrences?: number;
}

export interface Customer {
    id: number;
    name: string;
    phone: string;
}

export interface StockItem {
    id: number;
    name: string;
    category: string;
    quantity: number;
    buyingPrice: number;
    sellingPrice: number;
    lowStockThreshold: number;
}

export interface FinanceRecord {
    id: number;
    type: 'Income' | 'Expense';
    date: string;
    category: string;
    description: string;
    amount: number;
}

export interface Wholesaler {
    id: number;
    name: string;
    contactPerson: string;
    phone: string;
    productCategory: string;
}

export interface BodaDriver {
    id: number;
    name: string;
    phone: string;
    stage: string;
    riderId: string;
}

export interface Task {
    id: number;
    description: string;
    dueDate: string;
    status: 'Pending' | 'Completed';
}