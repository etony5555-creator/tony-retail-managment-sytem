import React, { useState, useEffect } from 'react';
import type { FinanceRecord } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface FinanceProps {
    records: FinanceRecord[];
    setRecords: React.Dispatch<React.SetStateAction<FinanceRecord[]>>;
}

const incomeCategories = ['Sales', 'Services', 'Other'];
const expenseCategories = ['Stock', 'Rent', 'Utilities', 'Salaries', 'Transport', 'Other'];

const FinanceModal: React.FC<{
    record: FinanceRecord | null;
    recordType: 'Income' | 'Expense';
    onClose: () => void;
    onSave: (record: FinanceRecord) => void;
}> = ({ record, recordType, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<FinanceRecord, 'id' | 'type'>>({
        date: new Date().toISOString().split('T')[0], category: '', description: '', amount: 0
    });
    
    useEffect(() => {
        const categories = recordType === 'Income' ? incomeCategories : expenseCategories;
        if (record) {
            setFormData({ date: record.date, category: record.category, description: record.description, amount: record.amount });
        } else {
            setFormData({ date: new Date().toISOString().split('T')[0], category: categories[0], description: '', amount: 0 });
        }
    }, [record, recordType]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'amount' ? Number(value) : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: record?.id || Date.now(), type: recordType, ...formData });
        onClose();
    };
    
    const categories = recordType === 'Income' ? incomeCategories : expenseCategories;

    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl text-gray-800 dark:text-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{record ? `Edit ${recordType}` : `Add ${recordType}`}</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Date</label>
                        <input type="date" name="date" id="date" value={formData.date} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary" />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category</label>
                        <select name="category" id="category" value={formData.category} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary">
                            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                     <div className="mb-4">
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label>
                        <input type="text" name="description" id="description" value={formData.description} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary" />
                    </div>
                    <div className="mb-6">
                        <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Amount (UGX)</label>
                        <input type="number" name="amount" id="amount" value={formData.amount} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary" />
                    </div>
                    <div className="flex justify-end space-x-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const Finance: React.FC<FinanceProps> = ({ records, setRecords }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingRecord, setEditingRecord] = useState<FinanceRecord | null>(null);
    const [recordType, setRecordType] = useState<'Income' | 'Expense'>('Income');

    const handleOpenModal = (type: 'Income' | 'Expense', record: FinanceRecord | null = null) => {
        setRecordType(type);
        setEditingRecord(record);
        setIsModalOpen(true);
    };

    const handleDeleteRecord = (recordId: number) => {
        if(window.confirm('Are you sure you want to delete this record?')) {
            setRecords(records.filter(r => r.id !== recordId));
        }
    };
    
    const handleSaveRecord = (record: FinanceRecord) => {
        const index = records.findIndex(r => r.id === record.id);
        if (index > -1) {
            const updatedRecords = [...records];
            updatedRecords[index] = record;
            setRecords(updatedRecords);
        } else {
            setRecords([...records, record]);
        }
    };

    const incomeRecords = records.filter(r => r.type === 'Income');
    const expenseRecords = records.filter(r => r.type === 'Expense');

    return (
        <div>
            {isModalOpen && <FinanceModal record={editingRecord} recordType={recordType} onClose={() => setIsModalOpen(false)} onSave={handleSaveRecord} />}
            <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light mb-6">Finance</h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Income Section */}
                <div>
                    <div className="flex flex-col gap-2 sm:flex-row sm:justify-between sm:items-center mb-4">
                        <h2 className="text-2xl font-semibold text-dark dark:text-light">Income</h2>
                        <button onClick={() => handleOpenModal('Income')} className="flex items-center self-start sm:self-auto px-4 py-2 bg-secondary text-white rounded-md hover:bg-emerald-600 shadow-sm transition-all">
                           <PlusIcon className="h-5 w-5 mr-2" /> Add Income
                        </button>
                    </div>
                    <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                           <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                                <tr>
                                    <th className="px-2 sm:px-4 py-3">Date</th>
                                    <th className="px-2 sm:px-4 py-3">Description</th>
                                    <th className="px-2 sm:px-4 py-3">Amount</th>
                                    <th className="px-2 sm:px-4 py-3"></th>
                                </tr>
                           </thead>
                           <tbody>
                               {incomeRecords.map(rec => (
                                   <tr key={rec.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                       <td className="px-2 sm:px-4 py-3">{rec.date}</td>
                                       <td className="px-2 sm:px-4 py-3">{rec.description}</td>
                                       <td className="px-2 sm:px-4 py-3">UGX {rec.amount.toLocaleString()}</td>
                                       <td className="px-2 sm:px-4 py-3 text-right space-x-1">
                                           <button onClick={() => handleOpenModal('Income', rec)} className="p-2 text-blue-500 hover:text-blue-700 dark:hover:text-blue-400"><EditIcon className="h-4 w-4" /></button>
                                           <button onClick={() => handleDeleteRecord(rec.id)} className="p-2 text-red-500 hover:text-red-700 dark:hover:text-red-400"><TrashIcon className="h-4 w-4" /></button>
                                       </td>
                                   </tr>
                               ))}
                           </tbody>
                        </table>
                         {incomeRecords.length === 0 && <p className="text-center text-gray-500 py-6">No income records yet.</p>}
                    </div>
                </div>
                {/* Expense Section */}
                <div>
                    <div className="flex flex-col gap-2 sm:flex-row sm:justify-between sm:items-center mb-4">
                        <h2 className="text-2xl font-semibold text-dark dark:text-light">Expenses</h2>
                        <button onClick={() => handleOpenModal('Expense')} className="flex items-center self-start sm:self-auto px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 shadow-sm transition-all">
                           <PlusIcon className="h-5 w-5 mr-2" /> Add Expense
                        </button>
                    </div>
                    <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                           <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                                <tr>
                                    <th className="px-2 sm:px-4 py-3">Date</th>
                                    <th className="px-2 sm:px-4 py-3">Description</th>
                                    <th className="px-2 sm:px-4 py-3">Amount</th>
                                    <th className="px-2 sm:px-4 py-3"></th>
                                </tr>
                           </thead>
                           <tbody>
                               {expenseRecords.map(rec => (
                                   <tr key={rec.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                       <td className="px-2 sm:px-4 py-3">{rec.date}</td>
                                       <td className="px-2 sm:px-4 py-3">{rec.description}</td>
                                       <td className="px-2 sm:px-4 py-3">UGX {rec.amount.toLocaleString()}</td>
                                       <td className="px-2 sm:px-4 py-3 text-right space-x-1">
                                           <button onClick={() => handleOpenModal('Expense', rec)} className="p-2 text-blue-500 hover:text-blue-700 dark:hover:text-blue-400"><EditIcon className="h-4 w-4" /></button>
                                           <button onClick={() => handleDeleteRecord(rec.id)} className="p-2 text-red-500 hover:text-red-700 dark:hover:text-red-400"><TrashIcon className="h-4 w-4" /></button>
                                       </td>
                                   </tr>
                               ))}
                           </tbody>
                        </table>
                        {expenseRecords.length === 0 && <p className="text-center text-gray-500 py-6">No expense records yet.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Finance;