
import React, { useState } from 'react';
import type { Customer } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface CustomersProps {
    customers: Customer[];
    setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
}

const CustomerModal: React.FC<{
    customer: Customer | null;
    onClose: () => void;
    onSave: (customer: Customer) => void;
}> = ({ customer, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<Customer, 'id'>>({
        name: customer?.name || '',
        phone: customer?.phone || '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: customer?.id || Date.now(), ...formData });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl text-gray-800 dark:text-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{customer ? 'Edit Customer' : 'Add Customer'}</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary" required />
                    </div>
                    <div className="mb-6">
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Phone</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary focus:border-primary" required />
                    </div>
                    <div className="flex justify-end space-x-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Customer</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const Customers: React.FC<CustomersProps> = ({ customers, setCustomers }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

    const handleOpenModal = (customer: Customer | null = null) => {
        setEditingCustomer(customer);
        setIsModalOpen(true);
    };

    const handleSaveCustomer = (customer: Customer) => {
        const index = customers.findIndex(c => c.id === customer.id);
        if (index > -1) {
            const updatedCustomers = [...customers];
            updatedCustomers[index] = customer;
            setCustomers(updatedCustomers);
        } else {
            setCustomers([...customers, customer]);
        }
    };

    const handleDeleteCustomer = (customerId: number) => {
        if (window.confirm('Are you sure you want to delete this customer?')) {
            setCustomers(customers.filter(c => c.id !== customerId));
        }
    };

    return (
        <div>
            {isModalOpen && <CustomerModal customer={editingCustomer} onClose={() => setIsModalOpen(false)} onSave={handleSaveCustomer} />}
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Customers</h1>
                <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Customer
                </button>
            </div>
            <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                        <tr>
                            <th className="px-3 sm:px-6 py-3">Name</th>
                            <th className="px-3 sm:px-6 py-3">Phone</th>
                            <th className="px-3 sm:px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customers.map(customer => (
                            <tr key={customer.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                <td className="px-3 sm:px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">{customer.name}</td>
                                <td className="px-3 sm:px-6 py-4">{customer.phone}</td>
                                <td className="px-3 sm:px-6 py-4 text-right space-x-2">
                                    <button onClick={() => handleOpenModal(customer)} className="p-2 text-blue-500 hover:text-blue-700 dark:hover:text-blue-400"><EditIcon className="h-5 w-5" /></button>
                                    <button onClick={() => handleDeleteCustomer(customer.id)} className="p-2 text-red-500 hover:text-red-700 dark:hover:text-red-400"><TrashIcon className="h-5 w-5" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {customers.length === 0 && <p className="text-center text-gray-500 py-6">No customers found.</p>}
            </div>
        </div>
    );
};

export default Customers;