
import React, { useState } from 'react';
import type { Wholesaler } from '../../types';
import { PlusIcon, EditIcon, TrashIcon } from '../icons/Icons';

interface WholesalersProps {
    wholesalers: Wholesaler[];
    setWholesalers: React.Dispatch<React.SetStateAction<Wholesaler[]>>;
}

const WholesalerModal: React.FC<{
    wholesaler: Wholesaler | null;
    onClose: () => void;
    onSave: (wholesaler: Wholesaler) => void;
}> = ({ wholesaler, onClose, onSave }) => {
    const [formData, setFormData] = useState<Omit<Wholesaler, 'id'>>({
        name: wholesaler?.name || '',
        contactPerson: wholesaler?.contactPerson || '',
        phone: wholesaler?.phone || '',
        productCategory: wholesaler?.productCategory || ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: wholesaler?.id || Date.now(), ...formData });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-dark-card rounded-lg p-8 w-full max-w-md shadow-xl">
                <h2 className="text-2xl font-bold mb-6 text-dark dark:text-light">{wholesaler ? 'Edit Wholesaler' : 'Add Wholesaler'}</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" required />
                    </div>
                    <div>
                        <label htmlFor="contactPerson" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Contact Person</label>
                        <input type="text" name="contactPerson" id="contactPerson" value={formData.contactPerson} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="productCategory" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Product Category</label>
                        <input type="text" name="productCategory" id="productCategory" value={formData.productCategory} onChange={handleChange} className="mt-1 w-full p-2 bg-gray-50 dark:bg-dark-accent border border-gray-300 dark:border-gray-600 rounded-md" />
                    </div>
                    <div className="flex justify-end space-x-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-dark-accent rounded-md">Cancel</button>
                        <button type="submit" className="btn btn-primary">Save Wholesaler</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const Wholesalers: React.FC<WholesalersProps> = ({ wholesalers, setWholesalers }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingWholesaler, setEditingWholesaler] = useState<Wholesaler | null>(null);

    const handleSave = (wholesaler: Wholesaler) => {
        const index = wholesalers.findIndex(w => w.id === wholesaler.id);
        if (index > -1) {
            setWholesalers(wholesalers.map(w => w.id === wholesaler.id ? wholesaler : w));
        } else {
            setWholesalers([...wholesalers, wholesaler]);
        }
    };

    const handleDelete = (id: number) => {
        if (window.confirm('Are you sure you want to delete this wholesaler?')) {
            setWholesalers(wholesalers.filter(w => w.id !== id));
        }
    };

    return (
        <div>
            {isModalOpen && <WholesalerModal wholesaler={editingWholesaler} onClose={() => setIsModalOpen(false)} onSave={handleSave} />}
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-6">
                <h1 className="text-2xl md:text-3xl font-bold text-dark dark:text-light">Wholesalers</h1>
                <button onClick={() => { setEditingWholesaler(null); setIsModalOpen(true); }} className="btn btn-primary flex items-center self-start sm:self-auto">
                    <PlusIcon className="h-5 w-5 mr-2" /> Add Wholesaler
                </button>
            </div>
            <div className="bg-white dark:bg-dark-card p-4 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-dark-accent">
                        <tr>
                            <th className="px-3 sm:px-6 py-3">Name</th>
                            <th className="px-3 sm:px-6 py-3">Contact Person</th>
                            <th className="px-3 sm:px-6 py-3">Phone</th>
                            <th className="px-3 sm:px-6 py-3">Products</th>
                            <th className="px-3 sm:px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {wholesalers.map(w => (
                            <tr key={w.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-dark-accent">
                                <td className="px-3 sm:px-6 py-4 font-medium">{w.name}</td>
                                <td className="px-3 sm:px-6 py-4">{w.contactPerson}</td>
                                <td className="px-3 sm:px-6 py-4">{w.phone}</td>
                                <td className="px-3 sm:px-6 py-4">{w.productCategory}</td>
                                <td className="px-3 sm:px-6 py-4 text-right space-x-2">
                                    <button onClick={() => { setEditingWholesaler(w); setIsModalOpen(true); }} className="p-2 text-blue-500 hover:text-blue-700"><EditIcon className="h-5 w-5" /></button>
                                    <button onClick={() => handleDelete(w.id)} className="p-2 text-red-500 hover:text-red-700"><TrashIcon className="h-5 w-5" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {wholesalers.length === 0 && <p className="text-center text-gray-500 py-6">No wholesalers found.</p>}
            </div>
        </div>
    );
};

export default Wholesalers;